class Cargo{

    private String type;

    public Cargo(String type){
        this.type=type;
    }

    public String getType(){
        return this.type;
    }

    

}
