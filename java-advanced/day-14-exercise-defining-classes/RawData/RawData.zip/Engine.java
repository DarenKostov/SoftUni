class Engine{

    private int power=0;


    public Engine(int power){
        this.power=power;
    }

    public int getPower(){
        return this.power;
    }
    
}
