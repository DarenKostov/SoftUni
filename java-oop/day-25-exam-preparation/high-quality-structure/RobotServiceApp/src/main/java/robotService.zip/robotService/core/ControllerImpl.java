package robotService.core;

public class ControllerImpl implements Controller {

	@Override
	public String addService(String type, String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addSupplement(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String supplementForService(String serviceName, String supplementType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addRobot(String serviceName, String robotType, String robotName, String robotKind, double price) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String feedingRobot(String serviceName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sumOfAll(String serviceName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getStatistics() {
		// TODO Auto-generated method stub
		return null;
	}

}
