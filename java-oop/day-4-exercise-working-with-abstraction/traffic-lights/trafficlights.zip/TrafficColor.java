public enum TrafficColor{
    GREEN,
    YELLOW,
    RED;
}

