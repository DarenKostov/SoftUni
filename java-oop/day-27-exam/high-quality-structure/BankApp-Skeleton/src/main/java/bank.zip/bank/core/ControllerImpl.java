package bank.core;

public class ControllerImpl implements Controller {

	@Override
	public String addBank(String type, String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addLoan(String type) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String returnedLoan(String bankName, String loanType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String addClient(String bankName, String clientType, String clientName, String clientID, double income) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String finalCalculation(String bankName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getStatistics() {
		// TODO Auto-generated method stub
		return null;
	}

}
